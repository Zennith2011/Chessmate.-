# ChessMate

Aplikasi Android pendamping belajar catur. Offline-first, tanpa akun.

**Status: Fase 1 dari 9** (kerangka proyek, tema, navigasi, Home UI).

## Struktur

```
lib/
  main.dart                 titik masuk, menyiapkan Riverpod
  app.dart                  MaterialApp.router + tema
  core/                     dipakai lintas fitur
    constants/  router/  storage/  theme/  widgets/
  features/                 satu folder per fitur
    <fitur>/
      presentation/         UI (halaman dan widget)
      application/          state (Riverpod)
      domain/               logika murni (tanpa Flutter/IO)
      data/                 penyimpanan (SharedPreferences, nanti SQLite)
test/                       unit test dan widget test
docs/BUILD_APK.md           cara menjalankan dan membuat APK
```

Aturan lapisan: UI hanya memanggil `application`, `application` memanggil `domain`
dan `data`. UI tidak menyentuh penyimpanan langsung.

## Yang sudah berfungsi di Fase 1
- Tema terang/gelap/ikut sistem, pilihan tersimpan di perangkat.
- Navigasi 5 tab (Home, Analisis, Review, Bot, Belajar) dengan GoRouter;
  Riwayat dan Pengaturan dibuka dari ikon di AppBar Home.
- Home UI: kartu sambutan, fitur utama, tips harian, aktivitas terakhir (kosong).
- Halaman Pengaturan (pilihan tema).

## Yang belum ada (jujur)
Halaman Analisis, Review, Bot, Belajar, dan Riwayat baru berupa halaman
"Belum aktif" yang menjelaskan fasenya. Papan catur, Stockfish, PGN, bot,
floating assistant, dan computer vision belum dibuat.

Cara menjalankan dan build APK: lihat [docs/BUILD_APK.md](docs/BUILD_APK.md).
