import 'package:chessmate/app.dart';
import 'package:chessmate/core/storage/shared_preferences_provider.dart';
import 'package:chessmate/features/analysis/presentation/analysis_page.dart';
import 'package:chessmate/features/bot_play/presentation/bot_play_page.dart';
import 'package:chessmate/features/game_review/presentation/game_review_page.dart';
import 'package:chessmate/features/home/presentation/home_page.dart';
import 'package:chessmate/features/learning/presentation/learning_page.dart';
import 'package:chessmate/features/settings/application/settings_providers.dart';
import 'package:chessmate/features/settings/presentation/settings_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> _pumpApp(WidgetTester tester) async {
  SharedPreferences.setMockInitialValues({});
  final prefs = await SharedPreferences.getInstance();
  await tester.pumpWidget(
    ProviderScope(
      overrides: [sharedPreferencesProvider.overrideWithValue(prefs)],
      child: const ChessMateApp(),
    ),
  );
  await tester.pumpAndSettle();
}

Finder _navIcon(IconData icon) => find.descendant(
      of: find.byType(NavigationBar),
      matching: find.byIcon(icon),
    );

void main() {
  testWidgets('aplikasi dibuka di Home', (tester) async {
    await _pumpApp(tester);

    expect(find.byType(HomePage), findsOneWidget);
    expect(find.text('Siap belajar catur?'), findsOneWidget);
    expect(find.byType(NavigationBar), findsOneWidget);
  });

  testWidgets('bottom navigation pindah ke tiap tab', (tester) async {
    await _pumpApp(tester);

    await tester.tap(_navIcon(Icons.analytics_outlined));
    await tester.pumpAndSettle();
    expect(find.byType(AnalysisPage), findsOneWidget);

    await tester.tap(_navIcon(Icons.fact_check_outlined));
    await tester.pumpAndSettle();
    expect(find.byType(GameReviewPage), findsOneWidget);

    await tester.tap(_navIcon(Icons.smart_toy_outlined));
    await tester.pumpAndSettle();
    expect(find.byType(BotPlayPage), findsOneWidget);

    await tester.tap(_navIcon(Icons.school_outlined));
    await tester.pumpAndSettle();
    expect(find.byType(LearningPage), findsOneWidget);

    await tester.tap(_navIcon(Icons.home_outlined));
    await tester.pumpAndSettle();
    expect(find.byType(HomePage), findsOneWidget);
  });

  testWidgets('tombol Mulai Analisis membuka tab Analisis', (tester) async {
    await _pumpApp(tester);

    await tester.tap(find.text('Mulai Analisis'));
    await tester.pumpAndSettle();

    expect(find.byType(AnalysisPage), findsOneWidget);
  });

  testWidgets('pengaturan: memilih tema Gelap mengubah themeMode',
      (tester) async {
    await _pumpApp(tester);

    await tester.tap(find.byTooltip('Pengaturan'));
    await tester.pumpAndSettle();
    expect(find.byType(SettingsPage), findsOneWidget);

    await tester.tap(find.text('Gelap'));
    await tester.pumpAndSettle();

    final container =
        ProviderScope.containerOf(tester.element(find.byType(SettingsPage)));
    expect(container.read(themeModeProvider), ThemeMode.dark);
  });
}
