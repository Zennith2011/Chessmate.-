import 'package:chessmate/features/home/domain/chess_tip.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('ChessTips', () {
    test('semua tip punya judul dan isi', () {
      for (final tip in ChessTips.all) {
        expect(tip.title.trim(), isNotEmpty);
        expect(tip.body.trim(), isNotEmpty);
      }
    });

    test('tanggal yang sama selalu menghasilkan tip yang sama', () {
      final morning = DateTime(2026, 3, 10, 6, 0);
      final night = DateTime(2026, 3, 10, 23, 59);
      expect(ChessTips.forDate(morning), same(ChessTips.forDate(night)));
    });

    test('hari berurutan menghasilkan tip berbeda', () {
      final today = ChessTips.forDate(DateTime(2026, 3, 10));
      final tomorrow = ChessTips.forDate(DateTime(2026, 3, 11));
      expect(today, isNot(same(tomorrow)));
    });

    test('tip berulang setelah semua tip terpakai', () {
      final start = DateTime(2026, 3, 10);
      final later = start.add(Duration(days: ChessTips.all.length));
      expect(ChessTips.forDate(start), same(ChessTips.forDate(later)));
    });

    test('tidak pernah error untuk semua hari dalam setahun', () {
      var date = DateTime(2026, 1, 1);
      while (date.year == 2026) {
        expect(ChessTips.forDate(date), isNotNull);
        date = date.add(const Duration(days: 1));
      }
    });
  });
}
