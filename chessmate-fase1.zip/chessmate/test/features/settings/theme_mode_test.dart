import 'package:chessmate/core/storage/shared_preferences_provider.dart';
import 'package:chessmate/features/settings/application/settings_providers.dart';
import 'package:chessmate/features/settings/data/settings_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<ProviderContainer> _container(Map<String, Object> initial) async {
  SharedPreferences.setMockInitialValues(initial);
  final prefs = await SharedPreferences.getInstance();
  final container = ProviderContainer(
    overrides: [sharedPreferencesProvider.overrideWithValue(prefs)],
  );
  addTearDown(container.dispose);
  return container;
}

void main() {
  group('SettingsRepository', () {
    test('default ke ThemeMode.system bila belum ada data', () async {
      SharedPreferences.setMockInitialValues({});
      final repo = SettingsRepository(await SharedPreferences.getInstance());
      expect(repo.readThemeMode(), ThemeMode.system);
    });

    test('nilai tidak dikenal dianggap system', () async {
      SharedPreferences.setMockInitialValues(
          {SettingsRepository.themeModeKey: 'ungu'});
      final repo = SettingsRepository(await SharedPreferences.getInstance());
      expect(repo.readThemeMode(), ThemeMode.system);
    });

    test('menulis lalu membaca mengembalikan nilai yang sama', () async {
      SharedPreferences.setMockInitialValues({});
      final repo = SettingsRepository(await SharedPreferences.getInstance());
      for (final mode in ThemeMode.values) {
        await repo.writeThemeMode(mode);
        expect(repo.readThemeMode(), mode);
      }
    });
  });

  group('themeModeProvider', () {
    test('awalnya system', () async {
      final container = await _container({});
      expect(container.read(themeModeProvider), ThemeMode.system);
    });

    test('membaca nilai tersimpan', () async {
      final container =
          await _container({SettingsRepository.themeModeKey: 'light'});
      expect(container.read(themeModeProvider), ThemeMode.light);
    });

    test('setThemeMode mengubah state dan menyimpan ke disk', () async {
      final container = await _container({});
      await container
          .read(themeModeProvider.notifier)
          .setThemeMode(ThemeMode.dark);

      expect(container.read(themeModeProvider), ThemeMode.dark);
      final prefs = container.read(sharedPreferencesProvider);
      expect(prefs.getString(SettingsRepository.themeModeKey), 'dark');
    });
  });
}
