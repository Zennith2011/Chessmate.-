import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Instance SharedPreferences. Nilainya WAJIB di-override di `main()`
/// (dan di test), karena pembuatannya bersifat async.
final sharedPreferencesProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError(
    'sharedPreferencesProvider harus di-override di ProviderScope.',
  );
});
