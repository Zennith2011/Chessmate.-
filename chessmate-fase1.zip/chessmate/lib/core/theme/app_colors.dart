import 'package:flutter/material.dart';

abstract final class AppColors {
  /// Warna dasar untuk menghasilkan seluruh skema warna Material 3.
  static const Color seed = Color(0xFF3A7D5C);

  /// Warna petak papan catur (dipakai dekorasi sekarang, papan asli di Fase 2).
  static const Color boardLight = Color(0xFFEEEED2);
  static const Color boardDark = Color(0xFF769656);
}
