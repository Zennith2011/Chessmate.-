import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Papan 8x8 kecil sebagai dekorasi/logo. Bukan papan permainan
/// (papan interaktif dibuat di Fase 2).
class MiniBoard extends StatelessWidget {
  const MiniBoard({super.key, this.size = 96, this.radius = 12});

  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return ExcludeSemantics(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: CustomPaint(
          size: Size.square(size),
          painter: const _MiniBoardPainter(),
        ),
      ),
    );
  }
}

class _MiniBoardPainter extends CustomPainter {
  const _MiniBoardPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / 8;
    final paint = Paint();
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        paint.color =
            (row + col).isEven ? AppColors.boardLight : AppColors.boardDark;
        canvas.drawRect(Rect.fromLTWH(col * cell, row * cell, cell, cell), paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
