abstract final class AppConstants {
  static const String appName = 'ChessMate';
  static const String appVersion = '0.1.0';
  static const String tagline = 'Pendamping belajar caturmu';
}
