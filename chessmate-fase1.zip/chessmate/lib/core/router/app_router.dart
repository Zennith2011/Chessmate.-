import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/analysis/presentation/analysis_page.dart';
import '../../features/bot_play/presentation/bot_play_page.dart';
import '../../features/game_review/presentation/game_review_page.dart';
import '../../features/history/presentation/history_page.dart';
import '../../features/home/presentation/home_page.dart';
import '../../features/learning/presentation/learning_page.dart';
import '../../features/settings/presentation/settings_page.dart';
import '../../features/shell/presentation/main_shell.dart';

/// Daftar path rute. Pakai konstanta ini, jangan menulis string manual.
abstract final class AppRoute {
  static const String home = '/home';
  static const String analysis = '/analysis';
  static const String review = '/review';
  static const String bot = '/bot';
  static const String learn = '/learn';
  static const String history = '/history';
  static const String settings = '/settings';
}

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: AppRoute.home,
    routes: [
      // 5 tab utama dengan bottom navigation. Tiap tab menyimpan state-nya.
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            MainShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoute.home,
                builder: (context, state) => const HomePage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoute.analysis,
                builder: (context, state) => const AnalysisPage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoute.review,
                builder: (context, state) => const GameReviewPage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoute.bot,
                builder: (context, state) => const BotPlayPage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: AppRoute.learn,
                builder: (context, state) => const LearningPage(),
              ),
            ],
          ),
        ],
      ),
      // Halaman di luar tab: dibuka dengan context.push dari ikon AppBar Home.
      GoRoute(
        path: AppRoute.history,
        builder: (context, state) => const HistoryPage(),
      ),
      GoRoute(
        path: AppRoute.settings,
        builder: (context, state) => const SettingsPage(),
      ),
    ],
  );
});
