class ChessTip {
  const ChessTip({required this.title, required this.body});

  final String title;
  final String body;
}

/// Kumpulan tips catur. Satu tip dipilih per hari (berganti tiap hari,
/// berulang setelah semua tip terpakai).
abstract final class ChessTips {
  static const List<ChessTip> all = [
    ChessTip(
      title: 'Kuasai pusat papan',
      body: 'Petak e4, d4, e5, dan d5 membuat bidakmu lebih leluasa bergerak. '
          'Rebut atau awasi pusat sejak awal permainan.',
    ),
    ChessTip(
      title: 'Kembangkan bidak ringan',
      body: 'Keluarkan kuda dan gajah lebih dulu. Hindari menggerakkan bidak '
          'yang sama berulang kali di pembukaan.',
    ),
    ChessTip(
      title: 'Rokade lebih awal',
      body: 'Rokade mengamankan raja dan menghubungkan benteng. '
          'Biasanya lakukan sebelum langkah ke-10.',
    ),
    ChessTip(
      title: 'Tanya: apa ancaman lawan?',
      body: 'Sebelum melangkah, lihat dulu apa yang dibidik lawan dengan '
          'langkah terakhirnya.',
    ),
    ChessTip(
      title: 'Kuda suka di tengah',
      body: 'Kuda di tepi papan menguasai lebih sedikit petak. '
          'Usahakan menempatkannya di dekat pusat.',
    ),
    ChessTip(
      title: 'Benteng butuh kolom terbuka',
      body: 'Benteng paling kuat di kolom tanpa bidak. '
          'Pindahkan ke sana setelah kolom terbuka.',
    ),
    ChessTip(
      title: 'Aktifkan raja di endgame',
      body: 'Saat bidak berat sudah sedikit, raja justru menjadi bidak '
          'penyerang dan pembela yang kuat.',
    ),
    ChessTip(
      title: 'Jangan terburu-buru dengan ratu',
      body: 'Ratu yang keluar terlalu dini mudah diburu sehingga kamu '
          'kehilangan waktu.',
    ),
    ChessTip(
      title: 'Cek skak, tangkapan, ancaman',
      body: 'Sebelum memilih langkah, periksa semua skak, tangkapan, dan '
          'ancaman, baik milikmu maupun lawan.',
    ),
    ChessTip(
      title: 'Kenali pola taktik dasar',
      body: 'Garpu, tusukan, dan serangan ganda muncul terus di permainan '
          'nyata. Latih sampai cepat dikenali.',
    ),
  ];

  /// Tip untuk tanggal tertentu. Hanya memakai tahun/bulan/hari.
  static ChessTip forDate(DateTime date) {
    final startOfYear = DateTime.utc(date.year, 1, 1);
    final today = DateTime.utc(date.year, date.month, date.day);
    final dayOfYear = today.difference(startOfYear).inDays;
    return all[dayOfYear % all.length];
  }
}
