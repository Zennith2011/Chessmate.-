import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/router/app_router.dart';
import '../../../core/widgets/mini_board.dart';
import '../../../core/widgets/section_header.dart';
import '../domain/chess_tip.dart';
import 'widgets/quick_action_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            MiniBoard(size: 28, radius: 6),
            SizedBox(width: 10),
            Text(AppConstants.appName),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Riwayat',
            icon: const Icon(Icons.history),
            onPressed: () => context.push(AppRoute.history),
          ),
          IconButton(
            tooltip: 'Pengaturan',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => context.push(AppRoute.settings),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: const [
            _HeroCard(),
            SizedBox(height: 20),
            SectionHeader('Fitur utama'),
            _FeatureGrid(),
            SizedBox(height: 8),
            SectionHeader('Alat cepat'),
            _UpcomingTools(),
            SizedBox(height: 20),
            SectionHeader('Tips hari ini'),
            _TipCard(),
            SizedBox(height: 20),
            SectionHeader('Aktivitas terakhir'),
            _RecentActivityEmpty(),
          ],
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Card.filled(
      margin: EdgeInsets.zero,
      color: scheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Siap belajar catur?',
                    style: textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: scheme.onPrimaryContainer,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Analisis posisi, review pertandingan, dan latihan '
                    'melawan bot. Semuanya bisa offline.',
                    style: textTheme.bodyMedium
                        ?.copyWith(color: scheme.onPrimaryContainer),
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: () => context.go(AppRoute.analysis),
                    icon: const Icon(Icons.analytics_outlined),
                    label: const Text('Mulai Analisis'),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            const MiniBoard(size: 88),
          ],
        ),
      ),
    );
  }
}

class _Feature {
  const _Feature({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.route,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String badge;
  final String route;
}

class _FeatureGrid extends StatelessWidget {
  const _FeatureGrid();

  static const List<_Feature> _features = [
    _Feature(
      icon: Icons.analytics_outlined,
      title: 'Analisis Posisi',
      subtitle: 'Cari langkah terbaik dengan Stockfish.',
      badge: 'Fase 5',
      route: AppRoute.analysis,
    ),
    _Feature(
      icon: Icons.fact_check_outlined,
      title: 'Review Pertandingan',
      subtitle: 'Impor PGN dan temukan kesalahan.',
      badge: 'Fase 5',
      route: AppRoute.review,
    ),
    _Feature(
      icon: Icons.smart_toy_outlined,
      title: 'Lawan Bot',
      subtitle: 'Main catur melawan bot offline.',
      badge: 'Fase 6',
      route: AppRoute.bot,
    ),
    _Feature(
      icon: Icons.school_outlined,
      title: 'Pusat Belajar',
      subtitle: 'Materi dan latihan taktik.',
      badge: 'Segera',
      route: AppRoute.learn,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    Widget cardFor(_Feature f) => QuickActionCard(
          icon: f.icon,
          title: f.title,
          subtitle: f.subtitle,
          badge: f.badge,
          onTap: () => context.go(f.route),
        );

    return Column(
      children: [
        for (var i = 0; i < _features.length; i += 2)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: cardFor(_features[i])),
                  const SizedBox(width: 12),
                  Expanded(
                    child: i + 1 < _features.length
                        ? cardFor(_features[i + 1])
                        : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _UpcomingTools extends StatelessWidget {
  const _UpcomingTools();

  void _showSoon(BuildContext context, String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Column(
      children: [
        Card.filled(
          margin: EdgeInsets.zero,
          child: ListTile(
            leading: const Icon(Icons.bubble_chart_outlined),
            title: const Text('Floating Assistant'),
            subtitle: const Text('Bantuan melayang di atas aplikasi lain'),
            trailing: Text('Fase 7',
                style: TextStyle(color: scheme.onSurfaceVariant)),
            onTap: () => _showSoon(
                context, 'Floating Assistant tersedia di Fase 7.'),
          ),
        ),
        const SizedBox(height: 8),
        Card.filled(
          margin: EdgeInsets.zero,
          child: ListTile(
            leading: const Icon(Icons.document_scanner_outlined),
            title: const Text('Scan Papan dari Screenshot'),
            subtitle: const Text('Kenali posisi catur dari gambar'),
            trailing: Text('Fase 8',
                style: TextStyle(color: scheme.onSurfaceVariant)),
            onTap: () =>
                _showSoon(context, 'Scan papan tersedia di Fase 8.'),
          ),
        ),
      ],
    );
  }
}

class _TipCard extends StatelessWidget {
  const _TipCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final tip = ChessTips.forDate(DateTime.now());

    return Card.filled(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.lightbulb_outline, color: scheme.tertiary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    tip.title,
                    style: textTheme.titleSmall
                        ?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    tip.body,
                    style: textTheme.bodyMedium
                        ?.copyWith(color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RecentActivityEmpty extends StatelessWidget {
  const _RecentActivityEmpty();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Card.filled(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Icon(Icons.history, size: 32, color: scheme.onSurfaceVariant),
            const SizedBox(height: 8),
            Text(
              'Belum ada aktivitas',
              style:
                  textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            Text(
              'Analisis dan pertandingan yang kamu simpan akan muncul di sini.',
              textAlign: TextAlign.center,
              style: textTheme.bodySmall
                  ?.copyWith(color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => context.push(AppRoute.history),
              child: const Text('Buka Riwayat'),
            ),
          ],
        ),
      ),
    );
  }
}
