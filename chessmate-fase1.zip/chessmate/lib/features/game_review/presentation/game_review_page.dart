import 'package:flutter/material.dart';

import '../../../core/widgets/feature_placeholder_page.dart';

class GameReviewPage extends StatelessWidget {
  const GameReviewPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const FeaturePlaceholderPage(
      icon: Icons.fact_check_outlined,
      title: 'Review',
      description:
          'Review pertandingan belum dibuat. Impor PGN dikerjakan di Fase 3, '
          'analisis kesalahan di Fase 5.',
      phaseLabel: 'Fase 3 dan 5',
      plannedFeatures: [
        'Impor pertandingan dari PGN',
        'Putar ulang langkah demi langkah',
        'Tandai kesalahan dan langkah terbaik',
      ],
    );
  }
}
