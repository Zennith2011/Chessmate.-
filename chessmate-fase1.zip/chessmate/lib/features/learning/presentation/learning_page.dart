import 'package:flutter/material.dart';

import '../../../core/widgets/feature_placeholder_page.dart';

class LearningPage extends StatelessWidget {
  const LearningPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const FeaturePlaceholderPage(
      icon: Icons.school_outlined,
      title: 'Belajar',
      description:
          'Pusat belajar belum dibuat dan belum punya fase sendiri dalam '
          'rencana. Kita tentukan jadwalnya setelah fase inti selesai.',
      phaseLabel: 'Belum dijadwalkan',
      plannedFeatures: [
        'Materi dasar: pembukaan, taktik, endgame',
        'Latihan soal taktik',
        'Progres belajar tersimpan offline',
      ],
    );
  }
}
