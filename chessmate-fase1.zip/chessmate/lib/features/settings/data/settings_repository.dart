import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Lapisan data untuk pengaturan. UI tidak boleh menyentuh
/// SharedPreferences langsung.
class SettingsRepository {
  SettingsRepository(this._prefs);

  final SharedPreferences _prefs;

  static const String themeModeKey = 'theme_mode';

  /// Nilai tidak dikenal atau belum ada => ikuti sistem.
  ThemeMode readThemeMode() {
    final stored = _prefs.getString(themeModeKey);
    return ThemeMode.values.firstWhere(
      (mode) => mode.name == stored,
      orElse: () => ThemeMode.system,
    );
  }

  Future<void> writeThemeMode(ThemeMode mode) async {
    await _prefs.setString(themeModeKey, mode.name);
  }
}
