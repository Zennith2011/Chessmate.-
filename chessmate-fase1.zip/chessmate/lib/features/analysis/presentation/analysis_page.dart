import 'package:flutter/material.dart';

import '../../../core/widgets/feature_placeholder_page.dart';

class AnalysisPage extends StatelessWidget {
  const AnalysisPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const FeaturePlaceholderPage(
      icon: Icons.analytics_outlined,
      title: 'Analisis',
      description:
          'Halaman analisis posisi belum dibuat. Papan catur dikerjakan di '
          'Fase 2, mesin Stockfish di Fase 4.',
      phaseLabel: 'Fase 2, 4, dan 5',
      plannedFeatures: [
        'Papan catur interaktif dengan aturan resmi',
        'Masukkan posisi lewat FEN',
        'Evaluasi dan langkah terbaik dari Stockfish',
      ],
    );
  }
}
