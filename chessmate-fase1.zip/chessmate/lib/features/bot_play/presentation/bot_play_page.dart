import 'package:flutter/material.dart';

import '../../../core/widgets/feature_placeholder_page.dart';

class BotPlayPage extends StatelessWidget {
  const BotPlayPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const FeaturePlaceholderPage(
      icon: Icons.smart_toy_outlined,
      title: 'Lawan Bot',
      description: 'Bermain melawan bot belum dibuat. Dikerjakan di Fase 6.',
      phaseLabel: 'Fase 6',
      plannedFeatures: [
        'Pilih tingkat kesulitan bot',
        'Main sebagai putih atau hitam',
        'Simpan pertandingan ke riwayat',
      ],
    );
  }
}
