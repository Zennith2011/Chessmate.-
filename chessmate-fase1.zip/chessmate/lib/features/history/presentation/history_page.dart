import 'package:flutter/material.dart';

import '../../../core/widgets/feature_placeholder_page.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const FeaturePlaceholderPage(
      icon: Icons.history,
      title: 'Riwayat',
      description:
          'Riwayat belum dibuat. Penyimpanan SQLite dipasang saat ada data '
          'yang perlu disimpan, mulai Fase 5.',
      phaseLabel: 'Fase 5 dan 6',
      plannedFeatures: [
        'Daftar analisis dan pertandingan tersimpan',
        'Buka kembali dan lanjutkan review',
        'Hapus riwayat',
      ],
    );
  }
}
