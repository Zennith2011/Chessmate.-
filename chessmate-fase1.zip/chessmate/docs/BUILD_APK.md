# Cara Menjalankan dan Membuat APK ChessMate

> **Status jujur:** kode Fase 1 ditulis tanpa Flutter terpasang, jadi belum pernah
> dikompilasi, dianalisis, atau dites. Langkah 4 dan 5 di bawah adalah cara kamu
> memverifikasinya. Jika ada error, salin pesan errornya dan kirim ke saya.

## Yang dibutuhkan

Membuat APK membutuhkan **komputer** (Windows, macOS, atau Linux). HP Android saja
tidak cukup untuk build. Alternatif tanpa memasang apa pun: Cara B (GitHub Actions)
di bawah, tapi tetap perlu mengunggah proyek ke GitHub (paling mudah dari komputer).

## Cara A: Build di komputer sendiri

### 1. Pasang alat
1. Pasang **Flutter SDK**: https://docs.flutter.dev/get-started/install
   (pilih sistem operasimu, target "Android").
2. Pasang **Android Studio** (membawa Android SDK). Buka sekali, lalu pasang
   "Android SDK Command-line Tools" lewat SDK Manager.
3. Di terminal jalankan `flutter doctor --android-licenses` lalu `flutter doctor`.
   Perbaiki semua tanda silang merah di bagian Flutter dan Android toolchain.

### 2. Buat kerangka Android
Kita buat kerangka di folder sementara, lalu salin hanya folder `android/`
supaya kode ChessMate tidak tertimpa. Jalankan dari folder **induk** `chessmate`:

```
flutter create --org com.chessmate --project-name chessmate --platforms android chessmate_scaffold
cp -r chessmate_scaffold/android chessmate/android
```

(Windows PowerShell: `Copy-Item -Recurse chessmate_scaffold\android chessmate\android`.)
Setelah itu `chessmate_scaffold` boleh dihapus. Lalu masuk ke folder proyek:
`cd chessmate`.

### 3. Atur Android 10 ke atas
Buka `android/app/build.gradle.kts` (atau `build.gradle` di Flutter lama), cari
`minSdk = flutter.minSdkVersion` (atau `minSdkVersion flutter.minSdkVersion`),
ganti menjadi `minSdk = 29` (atau `minSdkVersion 29`).

Buka `android/app/src/main/AndroidManifest.xml`, ubah `android:label="chessmate"`
menjadi `android:label="ChessMate"`.

### 4. Ambil dependency dan periksa kode
```
flutter pub get
flutter analyze
flutter test
```
Harapan: `flutter analyze` tanpa error, dan semua test lulus.

### 5. Jalankan di HP
1. HP: Pengaturan > Tentang ponsel > ketuk "Nomor build" 7 kali > aktifkan
   **Opsi pengembang > USB debugging**.
2. Colok HP ke komputer, izinkan debugging.
3. Jalankan `flutter devices` (HP harus muncul), lalu `flutter run`.

### 6. Build APK
```
flutter build apk --release --target-platform android-arm64
```
Hasil: `build/app/outputs/flutter-apk/app-release.apk`. Salin ke HP lalu buka untuk
memasang (izinkan "Pasang dari sumber tidak dikenal" jika diminta).

> APK ini ditandatangani dengan kunci debug sehingga cukup untuk uji pribadi.
> Untuk rilis sungguhan (Play Store) kita buat keystore sendiri di Fase 9.

## Cara B: Build lewat GitHub Actions (tanpa Flutter di komputer)

1. Buat akun dan repositori di github.com, unggah seluruh isi folder proyek
   (termasuk `.github/workflows/build-apk.yml`).
2. Buka tab **Actions** > **Build APK** > **Run workflow**.
3. Tunggu selesai, buka run tersebut, unduh artifact **chessmate-apk**
   (berisi `app-release.apk`).

Workflow ini belum pernah dijalankan. Jika gagal, kirim log langkah yang merah.

## Masalah yang umum
- `flutter doctor` menandai Android licenses: jalankan `flutter doctor --android-licenses`.
- Versi paket tidak cocok: jalankan `flutter upgrade`, lalu `flutter pub get`.
- Ada `test/widget_test.dart` yang gagal: file itu bawaan template, hapus saja.
